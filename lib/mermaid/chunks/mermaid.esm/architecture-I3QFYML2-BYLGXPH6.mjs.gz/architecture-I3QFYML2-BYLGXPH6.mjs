import {
  ArchitectureModule,
  createArchitectureServices
} from "./chunk-FKTRZSYK.mjs";
import "./chunk-46UCTVYF.mjs";
import "./chunk-TGZYFRKZ.mjs";
import "./chunk-GRZAG2UZ.mjs";
import "./chunk-HD3LK5B5.mjs";
import "./chunk-DLQEHMXD.mjs";
export {
  ArchitectureModule,
  createArchitectureServices
};
