import {
  ClassDB,
  classDiagram_default,
  classRenderer_v3_unified_default,
  styles_default
} from "./chunk-UAIL5EAE.mjs";
import "./chunk-SCLVSU6P.mjs";
import "./chunk-VH2OSJNQ.mjs";
import "./chunk-WDWNAAEG.mjs";
import "./chunk-BWYADPFM.mjs";
import "./chunk-SKKRN3KO.mjs";
import "./chunk-ZH73STAE.mjs";
import "./chunk-ZRZ2AMKI.mjs";
import "./chunk-SVWLYT5M.mjs";
import "./chunk-STRMIP24.mjs";
import "./chunk-4RZPZ3GF.mjs";
import "./chunk-ZNH7G2NJ.mjs";
import "./chunk-JGNW3ECZ.mjs";
import "./chunk-6PHMZWEM.mjs";
import "./chunk-2LXNVE6Q.mjs";
import "./chunk-PEQZQI46.mjs";
import {
  __name
} from "./chunk-DLQEHMXD.mjs";

// src/diagrams/class/classDiagram.ts
var diagram = {
  parser: classDiagram_default,
  get db() {
    return new ClassDB();
  },
  renderer: classRenderer_v3_unified_default,
  styles: styles_default,
  init: /* @__PURE__ */ __name((cnf) => {
    if (!cnf.class) {
      cnf.class = {};
    }
    cnf.class.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
  }, "init")
};
export {
  diagram
};
