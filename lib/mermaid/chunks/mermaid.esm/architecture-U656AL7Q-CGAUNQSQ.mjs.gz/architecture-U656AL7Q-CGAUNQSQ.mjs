import {
  ArchitectureModule,
  createArchitectureServices
} from "./chunk-2336245P.mjs";
import "./chunk-JFBLLWPX.mjs";
import "./chunk-ZZTYOBSU.mjs";
import "./chunk-PSZZOCOG.mjs";
import "./chunk-PEQZQI46.mjs";
import "./chunk-DLQEHMXD.mjs";
export {
  ArchitectureModule,
  createArchitectureServices
};
