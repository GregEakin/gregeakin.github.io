// package.json
var version = "11.4.0";

export {
  version
};
