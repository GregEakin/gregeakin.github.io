---
layout: post
title:  "Genetic AI!"
date:   2024-12-09 11:42:59 -0700
categories: software
---
How now? A [__C#__][csharp] version of the data structures from Chris Okasaki's book [_Purely Functional Data Structures_][cambridge],
coded as static functions to closely resemble the book's description.

[csharp]: https://en.wikipedia.org/wiki/C_Sharp_(programming_language)
[cambridge]: https://www.cambridge.org/core/books/purely-functional-data-structures/0409255DA1B48FA731859AC72E34D494

