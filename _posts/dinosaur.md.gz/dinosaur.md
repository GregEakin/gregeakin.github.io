---
layout: post
title:  "REX, My Long-Lost Friend."
date:   2025-05-31 08:42:59 -0700
categories: pictures
---

![REX, the dinosaur](assets/dinosaur.webp "REX, the dinosaur.")

Once upon a time, in a quiet suburban neighborhood, there lived a dinosaur named Rex. Rex wasn't just any dinosaur&mdash;he was a beloved member of the family. With his gentle eyes and thunderous tail wags, Rex quickly became everyone's favorite companion.
Rex's favorite game was fetch. Whether it was a stick, a ball, or the occasional car tire, he'd bound across the yard with surprising grace for a creature his size. The family loved taking him for long walks on the beach, where his footprints left craters in the sand and his laughter echoed with the crashing waves.
Rex was well-mannered, but he did have one regret: the day he accidentally ate the neighbor, Karen. It was a misunderstanding&mdash;she was wearing her famous meatloaf perfume, and Rex just couldn't resist. Though the family forgave him, Rex still looks wistfully across the fence, wishing he could take it back.
To this day, Rex remains a legend in the neighborhood&mdash;a reminder that even the biggest pets can have the biggest hearts (and sometimes, the biggest appetites).
